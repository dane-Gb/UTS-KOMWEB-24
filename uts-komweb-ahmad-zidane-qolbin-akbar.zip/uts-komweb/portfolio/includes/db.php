<?php
$servername = "localhost";
$username = "root";  // Ganti dengan username MySQL kamu
$password = "";  // Ganti dengan password MySQL kamu
$dbname = "portfolio_db1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

