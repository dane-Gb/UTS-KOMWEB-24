<?php

function url_dasar() {
    // Ambil URL dasar berdasarkan root dari proyek
    $url_dasar = "http://" . $_SERVER['SERVER_NAME'] . dirname($_SERVER['SCRIPT_NAME']);
    return rtrim($url_dasar, '/'); // Hapus slash di akhir jika ada
}

function gambarAbout($id) {
    global $conn;

    // Query untuk mengambil data dari tabel about
    $sql1 = "SELECT * FROM about WHERE id = '$id'";
    $q1 = mysqli_query($conn, $sql1);

    if (!$q1 || mysqli_num_rows($q1) == 0) {
        return null; // Jika query gagal atau tidak ada data, kembalikan null
    }

    // Ambil data dari hasil query
    $r1 = mysqli_fetch_array($q1);

    // Ambil isi dari kolom description yang mengandung tag <img>
    $text = $r1['description']; // Pastikan kolom ini benar di tabel

    // Cari elemen <img> dan ambil atribut src menggunakan regex
    preg_match('/<img[^>]+src=["\']\s*([^"\']+)\s*["\']/', $text, $img);

    if (isset($img[1])) {
        // Jika ditemukan, ambil src dan ganti path-nya dengan URL yang benar
        $gambar = $img[1]; // Misalnya: ../images/filename
        $gambar = str_replace("./images/home-img,jpeg", url_dasar() . "./images/home-img,jpeg", $gambar);
        return $gambar;
    } else {
        return null; // Jika tidak ditemukan <img> atau src
    }
}
?>
