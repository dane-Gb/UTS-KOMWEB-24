</div>
<footer class="bg-dark text-white text-center py-3">
  <p>© 2024 My Portfolio | Follow me on
    <a href="#" class="text-white"><i class="fab fa-facebook-f"></i></a>
    <a href="#" class="text-white"><i class="fab fa-twitter"></i></a>
    <a href="https://www.linkedin.com/in/ahmad-zidane-8a9a2828a/" class="text-white"><i class="fab fa-linkedin-in"></i></a>
  </p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/scripts.js"></script>
</body>
</html>

