<?php include 'includes/header.php'; ?>
<?php include 'includes/db.php'; ?>

<h2>Education</h2>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Degree</th>
            <th>Institution</th>
            <th>Year</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT degree, institution, year FROM education";
        $result = $conn->query($sql);
        
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row['degree'] . "</td><td>" . $row['institution'] . "</td><td>" . $row['year'] . "</td></tr>";
        }
        ?>
    </tbody>
</table>

<?php include 'includes/footer.php'; ?>
