<?php include 'includes/header.php'; ?>
<?php include 'includes/db.php'; ?>

<h2>Skills</h2>
<?php
$sql = "SELECT skill_name, proficiency FROM skills";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    echo '
    <div class="mb-4">
        <h5>'.$row['skill_name'].'</h5>
        <div class="progress">
            <div class="progress-bar" role="progressbar" style="width: '.$row['proficiency'].'%;" aria-valuenow="'.$row['proficiency'].'" aria-valuemin="0" aria-valuemax="100">'.$row['proficiency'].'%</div>
        </div>
    </div>';
}
?>

<?php include 'includes/footer.php'; ?>
