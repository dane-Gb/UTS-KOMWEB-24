// Smooth Scroll to Section
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Carousel Auto-Play Interval
var myCarousel = document.querySelector('#portfolioCarousel');
var carousel = new bootstrap.Carousel(myCarousel, {
  interval: 3000,
  wrap: true
});

// Button Hover Effect
document.querySelectorAll('.btn-dark').forEach(button => {
    button.addEventListener('mouseenter', function () {
        this.style.transform = 'scale(1.05)';
    });
    button.addEventListener('mouseleave', function () {
        this.style.transform = 'scale(1)';
    });
});
