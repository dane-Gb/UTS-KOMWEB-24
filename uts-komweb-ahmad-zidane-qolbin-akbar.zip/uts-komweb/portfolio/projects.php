<?php include 'includes/header.php'; ?>
<?php include 'includes/db.php'; ?>

<h2>Projects</h2>

<div class="row">
    <?php
    // Query untuk mengambil data dari tabel "projects"
    $sql = "SELECT project_name, description, project_url FROM projects";
    $result = mysqli_query($conn, $sql);

    // Cek apakah query berhasil
    if (!$result) {
        die("Query gagal: " . mysqli_error($conn));
    }

    // Cek apakah ada data
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">' . htmlspecialchars($row['project_name']) . '</h5>
                        <p class="card-text">' . htmlspecialchars($row['description']) . '</p>
                        <a href="' . htmlspecialchars($row['project_url']) . '" class="btn btn-dark">View Project</a>
                    </div>
                </div>
            </div>';
        }
    } else {
        echo '<p>No projects found.</p>';
    }

    // Menutup koneksi
    mysqli_close($conn);
    ?>
</div>

<?php include 'includes/footer.php'; ?>
