<?php include 'includes/header.php'; ?>

<div id="portfolioCarousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/about-img.jpg" class="d-block w-100" alt="Portfolio Banner">
      <div class="carousel-caption d-none d-md-block">
        <h1>Welcome to My Portfolio</h1>
        <p>Explore my works, skills, and contact me for collaborations!</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/home-img.jpg" class="d-block w-100" alt="Portfolio Banner 2">
      <div class="carousel-caption d-none d-md-block">
        <h1>Discover My Projects</h1>
        <p>Check out my completed and ongoing projects.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#portfolioCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#portfolioCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div class="row mt-4">
  <div class="col-md-4">
    <div class="card">
      <img src="images/banner1.jpeg" class="card-img-top" alt="Projects">
      <div class="card-body">
        <h5 class="card-title">My Projects</h5>
        <p class="card-text">Explore the projects I've worked on and the solutions I’ve created.</p>
        <a href="projects.php" class="btn btn-dark">View Projects</a>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card">
      <img src="images/img-about.jpeg" class="card-img-top" alt="About Me">
      <div class="card-body">
        <h5 class="card-title">About Me</h5>
        <p class="card-text">Learn more about my background, education, and interests.</p>
        <a href="about.php" class="btn btn-dark">Learn More</a>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card">
      <img src="images/banner2.jpeg" class="card-img-top" alt="Skills">
      <div class="card-body">
        <h5 class="card-title">My Skills</h5>
        <p class="card-text">Discover the technical and soft skills that I bring to the table.</p>
        <a href="skills.php" class="btn btn-dark">See Skills</a>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
