<?php include 'includes/header.php'; ?>
<?php include 'includes/db.php'; ?>
<?php include 'includes/function.php';?>

<h2 class="text-center my-4">About Me</h2> <!-- Tambah text-center dan margin-top-bottom untuk judul -->

<div class="card mb-3 shadow-lg">
  <div class="row g-0 align-items-center"> <!-- align-items-center agar gambar dan teks sejajar secara vertikal -->
    <div class="col-md-4">
      <img src="images/zidane1.png" class="img-fluid rounded-start" alt="Deskripsi Gambar" style="object-fit: cover; height: 100%; width: 100%;"> <!-- Gambar full-width dan object-fit untuk proporsional -->
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title fw-bold">Who Am I?</h5>
        <p class="card-text">
        <?php
        $sql = "SELECT description FROM about";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc()) {
            echo $row['description'];
        }
        ?>
        </p>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
